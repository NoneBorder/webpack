module.exports = {
	entry: ["react", "react-dom", "lodash"]
};
