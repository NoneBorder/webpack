module.exports = "foo";
