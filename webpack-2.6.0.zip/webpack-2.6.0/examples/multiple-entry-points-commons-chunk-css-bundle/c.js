require("./styleC.css");
