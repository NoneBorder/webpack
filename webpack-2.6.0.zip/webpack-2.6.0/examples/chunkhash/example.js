import vendor from "./vendor";
// some module
import("./async1");
import("./async2");
