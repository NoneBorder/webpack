console.log(require("./vendor"));
module.exports = "pageA";