module.exports = function(content) {
	return "exports.answer = 42;\n" + content;
}