
# example.js

``` javascript
{{example.js}}
```

# style.css

``` css
{{style.css}}
```

# chunk.js

``` javascript
{{chunk.js}}
```

# style2.css

``` css
{{style2.css}}
```

# webpack.config.js

``` javascript
{{webpack.config.js}}
```

# js/style.css

``` javascript
{{js/style.css}}
```

# Info

## Uncompressed

```
{{stdout}}
```

## Minimized (uglify-js, no zip)

```
{{min:stdout}}
```
