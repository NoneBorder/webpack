export var answer = 42;
