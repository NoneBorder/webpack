
# example.js

``` javascript
{{example.js}}
```

# increment.js

``` javascript
{{increment.js}}
```

# js/output.js

``` javascript
{{js/output.js}}
```

# Info

## Uncompressed

```
{{stdout}}
```

## Minimized (uglify-js, no zip)

```
{{min:stdout}}
```