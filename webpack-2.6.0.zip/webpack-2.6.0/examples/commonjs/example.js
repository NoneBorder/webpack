var inc = require('./increment').increment;
var a = 1;
inc(a); // 2