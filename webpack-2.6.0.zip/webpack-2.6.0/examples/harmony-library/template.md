# webpack.config.js

``` javascript
{{webpack.config.js}}
```

# js/MyLibrary.umd.js

``` javascript
{{js/MyLibrary.umd.js}}
```

# Info

## Uncompressed

```
{{stdout}}
```

## Minimized (uglify-js, no zip)

```
{{min:stdout}}
```
